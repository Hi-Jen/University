<?php
$conn = mysqli_connect('localhost', 'root', 'admin#2024');
mysqli_select_db($conn, 'DB20213032');

$sql = "CREATE TABLE data (
    uid VARCHAR(20) NOT NULL,
    kor INT NOT NULL,
    eng INT NOT NULL,
    math INT NOT NULL,
    sci INT NOT NULL,
    hist INT NOT NULL,
    PRIMARY KEY (uid)
) DEFAULT CHARSET=utf8;";

if (!mysqli_query($conn, $sql)) {
    echo 'Error creating table: ' . mysqli_error($conn) . "\n";
} else {
    echo 'Table data is created' . "\n";
}

mysqli_close($conn);
?>
