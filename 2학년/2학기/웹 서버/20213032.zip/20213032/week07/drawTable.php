<?php
$conn = mysqli_connect('localhost', 'root', 'admin#2024');
mysqli_select_db($conn, 'DB20213032');

$sql = "select * from data";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($result)) {
    echo $row['uid']. " ";
    echo $row['kor']. " ";
    echo $row['eng']. " ";
    echo $row['math']. " ";
    echo $row['sci']. " ";
    echo $row['hist']. " "; "<br>";
    echo "<br>";
}

mysqli_close($conn);
?>