<?php
$conn = mysqli_connect('localhost', 'root', 'admin#2024');
mysqli_select_db($conn, 'DB20213032');

for ($i = 0; $i < 10; $i++) {
    $uid = sprintf('202400%02d', $i + 1); 
    $kor = rand(51, 100);
    $eng = rand(51, 100);
    $math = rand(51, 100); 
    $sci = rand(51, 100);
    $hist = rand(51, 100);

    $sql = "INSERT INTO data (uid, kor, eng, math, sci, hist) VALUES ('$uid', $kor, $eng, $math, $sci, $hist);";
    
    echo $sql . "<br/>";
    
    if (!mysqli_query($conn, $sql)) {
        echo 'Error inserting data: ' . mysqli_error($conn) . "\n";
    } else {
        echo 'Data is inserted' . "\n";
    }
}

mysqli_close($conn);
?>
