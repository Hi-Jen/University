<?php
$name = $_POST['username'];
 echo 'username:'. $name. "<br/>";

 $name = $_POST['cars'];
 echo 'cars:'. $name. "<br/>";

 $name = $_POST['vehicle1'];
 echo 'vehicle1:'. $name. "<br/>";

 $name = $_POST['vehicle2'];
 echo 'vehicle2:'. $name. "<br/>";

 $name = $_POST['vehicle3'];
 echo 'vehicle3:'. $name. "<br/>";

 $name = $_POST['fav_language'];
 echo 'fav_language:'. $name. "<br/>";
 ?>
 <P> 20213032 권영훈 </P>

