<meta charset="utf-8">
<link rel="StyleSheet"href="./table.css"type="text/css"/>

<?php
$myfile = fopen("data.txt", "r") or die("Unable tp open file!");
$jsonData = fread($myfile, filesize("data.txt"));
fclose($myfile);
$data = json_decode($jsonData, true);
?>

<?php
echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>학번</th>";

$subject = array("국어", "영어", "수학", "과학", "역사");

foreach ($subject as $s) {
    echo "<th>" . $s . "</th>";
}
echo "</tr>";
echo "</thead>";

echo "<tbody>";

foreach ($data as $studentId => $scores) {
    echo "<tr>";
    
    echo "<td><a href='./makeGraph.php?sn=" . $studentId . "' target='_blank'>" . $studentId . "</a></td>";
    
    // 각 과목 점수 출력
    foreach ($scores as $score) {
        echo "<td>" . $score . "</td>";
    }
    
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";
?>
