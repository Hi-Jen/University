from ultralytics import YOLO

model = YOLO("yolov8n.pt")  

results = model.train(
    data="/home/team404/yolo/data.yaml",
    epochs=30,
    imgsz=640,
    batch=100,
    name="face_cover_model"
)
