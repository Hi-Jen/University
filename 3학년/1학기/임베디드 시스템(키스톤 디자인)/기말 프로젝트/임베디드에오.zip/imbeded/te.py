import yaml
with open('./data.yaml', 'r') as f: data = yaml.safe_load(f)
data['train'] = './train.txt'
data['val'] = './val.txt'
with open('./data.yaml', 'w') as f: yaml.dump(data,f)