import eventlet
from engineio.payload import Payload
Payload.max_decode_packets = 100
eventlet.monkey_patch()

from flask import render_template
from flask import Flask, Response, send_file
from flask_socketio import SocketIO, emit
import cv2
import numpy as np
import threading
import time
from ultralytics import YOLO
from eventlet.green import ssl

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins='*')
lock = threading.Lock()

latest_frame = None
yolo_enabled = True
fps = 0.0
model = YOLO("best.pt")

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('toggle_detect')
def handle_toggle(state):
    global yolo_enabled
    yolo_enabled = bool(state)

@socketio.on('frame')
def handle_frame(data):
    
    global latest_frame, fps

    start_time = time.time()
    jpg_bytes = np.frombuffer(data, dtype=np.uint8)
    frame = cv2.imdecode(jpg_bytes, cv2.IMREAD_COLOR)

    if frame is not None:
        if yolo_enabled:
            results = model(frame, verbose=False)
            annotated = results[0].plot()
        else:
            annotated = frame

        with lock:
            latest_frame = annotated

        fps = 1.0 / max((time.time() - start_time), 1e-6)
        socketio.emit("server_info", {
            "fps": f"{fps:.1f}",
            "width": frame.shape[1],
            "height": frame.shape[0]
        })

def generate():
    global latest_frame
    while True:
        with lock:
            if latest_frame is not None:
                ret, jpeg = cv2.imencode('.jpg', latest_frame)
                if ret:
                    frame = jpeg.tobytes()
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        eventlet.sleep(0.03)

@app.route('/video_feed')
def video_feed():
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    # 인증서 관련 코드 없이 일반 소켓 사용
    listener = eventlet.listen(('0.0.0.0', 8000))
    eventlet.wsgi.server(listener, app)
