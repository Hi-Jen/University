import cv2
import numpy as np

def preprocessing(no):  # 전처리, 파일 번호(0~59, 70, 72)
    path = "images/face/%d.jpg" % no   # 번호로 파일 불러오기
    image = cv2.imread(path, cv2.IMREAD_COLOR)
    if image is None: return None, None  # 원영상, 처리결과영상반환
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # 명암도 영상 변환
    gray = cv2.equalizeHist(gray) # 히스토그램 평활화
    return image, gray       # 원영상, 처리결과영상반환


face_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_frontalface_alt2.xml") # 얼굴 검출기

image, gray = preprocessing(71)  # 전처리 수행, 파일명 번호 전달
if image is None:
    raise Exception("이미지 파일 읽기 실패")

 # 얼굴검출결과반환(n, 4) shape 배열, [ [82 30 45 45]  [25 47 41 41] ... ]
faces = face_cascade.detectMultiScale(gray, 1.1, 2, 0, (100, 100));  

# 얼굴 표시 # if faces.any(): # 얼굴 검출한 경우
if len(faces):
    for (x, y, w, h) in faces:
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
else:
    print("얼굴 미검출")

cv2.imshow("Detected Faces", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
