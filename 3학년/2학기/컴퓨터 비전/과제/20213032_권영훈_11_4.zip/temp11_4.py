import cv2
import numpy as np

    # 다음 파일들이 소스 파일 있는 위치에 존재
prototxt = "SSD_data/deploy.prototxt"
caffemodel = "SSD_data/res10_300x300_ssd_iter_140000_fp16.caffemodel"

detector = cv2.dnn.readNet(prototxt, caffemodel)
 
cap = cv2.VideoCapture(0)
print("프로그램 실행 후 ESC 키를 누르면 종료됩니다.")

if not cap.isOpened():
    print("카메라를 열 수 없습니다.")
    exit()

threshold = 0.8  # 신뢰도 임계값

while True:
    ret, frame = cap.read()
    if not ret:
        print("프레임을 읽을 수 없습니다.")
        break

    h, w = frame.shape[:2]
    target_size = (300, 300)
    
    # 네트워크 입력용 이미지 전처리
    blob = cv2.dnn.blobFromImage(cv2.resize(frame, target_size),
                                 1.0, target_size,
                                 (104.0, 177.0, 123.0))  # mean 값 보정
    detector.setInput(blob)
    detections = detector.forward()
    results = detections[0][0]

    for i in range(0, results.shape[0]):
        conf = results[i, 2]
        if conf < threshold:
            continue

        # 얼굴 영역 계산
        box = results[i, 3:7] * np.array([w, h, w, h])
        (startX, startY, endX, endY) = box.astype("int")

        # 신뢰도와 얼굴 박스 출력
        text = f"{conf:.2f}"
        cv2.putText(frame, text, (startX, startY - 10),
                    cv2.FONT_HERSHEY_PLAIN, 1.2, (0, 255, 0), 2)
        cv2.rectangle(frame, (startX, startY), (endX, endY),
                      (0, 255, 0), 2)

    cv2.imshow("SSD Face", frame)

    # ESC 키(27) 누르면 종료
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()

