import cv2

def preprocessing(no):  # 전처리
    path = "images/face/%d.jpg" % no
    image = cv2.imread(path, cv2.IMREAD_COLOR)
    if image is None: 
        return None, None
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    return image, gray

face_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_frontalface_alt2.xml")
eye_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_eye.xml")
mouth_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_mcs_mouth.xml")


# 업로드한 이미지 경로
image, gray = preprocessing(71)
if image is None:
    raise Exception("영상 파일 읽기 에러")

# 얼굴 검출
faces = face_cascade.detectMultiScale(gray, 1.1, 5, 0, (100, 100))

if len(faces) == 0:
    print("얼굴 미검출")

for (x, y, w, h) in faces:
    # 얼굴 영역 표시
    cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
    face_gray = gray[y:y+h, x:x+w]
    face_color = image[y:y+h, x:x+w]

    # 눈 검출
    eyes = eye_cascade.detectMultiScale(face_gray, 1.01, 5, 0, (25, 10))
    for (ex, ey, ew, eh) in eyes[:2]:  
        center = (x + ex + ew//2, y + ey + eh//2)
        cv2.circle(image, center, 10, (0, 255, 0), 2)

    # 입 검출 
    roi_gray = face_gray[h//2:h, :]  
    roi_color = face_color[h//2:h, :]
    mouths = mouth_cascade.detectMultiScale(roi_gray, 1.3, 15)
    for (mx, my, mw, mh) in mouths[:1]:  
        cv2.rectangle(roi_color, (mx, my), (mx+mw, my+mh), (0, 0, 255), 2)

cv2.imshow("image", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
