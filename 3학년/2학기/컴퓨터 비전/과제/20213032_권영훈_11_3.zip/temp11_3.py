import cv2

def preprocessing(no):
    path = "images/face/%d.jpg" % no
    image = cv2.imread(path, cv2.IMREAD_COLOR)
    if image is None:
        return None, None
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    return image, gray

def detect_and_draw(image, gray, face_cascade, eye_cascade, mouth_cascade):
    faces = face_cascade.detectMultiScale(gray, 1.1, 5, 0, (100, 100))

    if len(faces) == 0:
        print("얼굴 미검출")
        return image

    for (x, y, w, h) in faces:
        
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
        face_gray = gray[y:y+h, x:x+w]
        face_color = image[y:y+h, x:x+w]

        eye_gray = face_gray[0:int(h*2/3), :]
        eyes = eye_cascade.detectMultiScale(eye_gray, 1.01, 5, 0, (25, 10))
        if len(eyes) == 0:
            print("눈 미검출")
        for (ex, ey, ew, eh) in eyes[:2]:
            center = (x + ex + ew//2, y + ey + eh//2)
            cv2.circle(image, center, 10, (0, 255, 0), 2)

        mouth_gray = face_gray[int(h/2):h, :]
        mouths = mouth_cascade.detectMultiScale(mouth_gray, 1.3, 15)
        if len(mouths) == 0:
            print("입 미검출")
        for (mx, my, mw, mh) in mouths[:1]:
            cv2.rectangle(face_color[int(h/2):h, :], (mx, my), (mx+mw, my+mh), (0, 0, 255), 2)

    return image


def detect_faces_file(face_cascade, eye_cascade, mouth_cascade):
    image, gray = preprocessing(71)   # 예시: 71번 파일
    if image is None:
        raise Exception("영상 파일 읽기 실패")

    result = detect_and_draw(image, gray, face_cascade, eye_cascade, mouth_cascade)
    cv2.imshow("File Result", result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def detect_faces_cam(face_cascade, eye_cascade, mouth_cascade):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise Exception("카메라 연결 실패")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("프레임 읽기 실패")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)

        result = detect_and_draw(frame, gray, face_cascade, eye_cascade, mouth_cascade)

        cv2.imshow("Camera Result", result)

        if cv2.waitKey(30) == 27:  # ESC 종료
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":

    face_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_frontalface_alt2.xml")
    eye_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_eye.xml")
    mouth_cascade = cv2.CascadeClassifier("images/Haar_file/haarcascade_mcs_mouth.xml")

    print("==== 얼굴/눈/입 검출 프로그램 ====")
    print("1. 파일에서 검출")
    print("2. 카메라에서 검출")
    mode = input("번호 선택 >> ")
    print("실행 시 ESC 키로 종료")

    if mode == "1":
        detect_faces_file(face_cascade, eye_cascade, mouth_cascade)
    elif mode == "2":
        detect_faces_cam(face_cascade, eye_cascade, mouth_cascade)
    else:
        print("잘못된 입력. 프로그램 종료")
